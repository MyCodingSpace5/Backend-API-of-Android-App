﻿using System;
namespace Android_Api
{
	public enum Permissions
	{
		StandardUser,
		Adminstrator,
		Developer
	}
}

