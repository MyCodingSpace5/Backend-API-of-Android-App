﻿using System;
namespace Android_Api
{
	public class Users
	{
		public List<Property> properties;
		public String username;
		public Permissions Role;
		public Users(String newusername, List<Property> newproperties)
		{
			this.username = newusername;
			this.properties = newproperties;
		}
	}
}

