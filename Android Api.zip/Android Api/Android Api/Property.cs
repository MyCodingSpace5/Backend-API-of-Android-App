﻿using System;
namespace Android_Api
{
	public class Property
	{
		public String name { get; set; }
		public int askingprice { get; set; }
		public String address { get; set; }
		public int position { get; set; }
		public String tag { get; set; } 
		public Property(String propertyname, int price, String address, String username)
		{
			this.name = propertyname;
			this.askingprice = price;
			this.address = address;
			this.tag = username;
		}
	}
}

