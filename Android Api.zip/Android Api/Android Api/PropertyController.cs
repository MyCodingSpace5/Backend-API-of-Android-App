﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Android_Api
{
    public class PropertyController : Controller
    {
        public List<Property> properties;
        [HttpGet("address"),("user")]
        public Property HttpGet(int newposition, Users user)
        {
            return properties.Find(x=>x.position==newposition);
        }
        [HttpPost("property"),("user")]
        public void HttpPost(Property property, Users user)
        {
            properties.Add(property);
        }
        [HttpDelete("position"),("username")]
        public void HttpDelete(int nposition, Users user)
        {
            Property zProperty = properties.Find(y => y.position == nposition);
            if (zProperty.tag == user.username)
            {
                properties.Remove(zProperty);
            }
            
        }

    }
}